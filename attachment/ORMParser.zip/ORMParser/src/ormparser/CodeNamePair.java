/**
 * This class is used to keep the code and name of field.
 * For example, a table is stored in XML like (Table$0, Customer)
 * In this class, the first part is "Table$0", and the second part is "Customer"
 */
package ormparser;

/**
 *
 * @author tang
 */
public class CodeNamePair<T> {
    private T first;
    private T second;
    
    public CodeNamePair(){
    
    }
    
    public CodeNamePair(T first, T second){
        this.first = first;
        this.second = second;
    }
    
    public T getFirst(){
        return this.first;
    }
    
    public void setFirst(T first){
        this.first = first;
    }
    
    public T getSecond(){
        return this.second;
    }
        
    public void setSecond(T second){
        this.second = second;
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ormparser;

/**
 *
 * @author tang
 */
public class Main {
    public static void main(String[] args){
        String input = "/Users/tang/Dropbox/Study/Research/ORM/CustomerOrderExample/model/Solutions_2/mapping_run_2_Sol_1.xml";
        //String input = "/Users/tang/Desktop/stock.xml";
        String output = "/Users/tang/Desktop/output.txt";
        ORMParser myParser = new ORMParser(input, output);
        myParser.toSQL();
    }
}

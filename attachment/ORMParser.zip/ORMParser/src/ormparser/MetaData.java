/**
 * This class is used to store the meta data. Meta data means the parsed data
 * from XML file
 */
package ormparser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 *
 * @author tang
 */
public class MetaData {

    // pairs is used to store all code and real name
    // for example, a table pair will be <Table$0, Customer>
    // a field pair will be <field$1, customerID>
    private ArrayList<CodeNamePair> pairs;
    private HashMap<String, HashMap<String, String>> tableItems;
    private ArrayList<CodeNamePair> types;

    public MetaData() {
        pairs = new ArrayList<CodeNamePair>();
        tableItems = new HashMap<String, HashMap<String, String>>();
        types = new ArrayList<CodeNamePair>();
        //assert TableName.size() == TableItem.size();
    }

    public boolean addPair(String code, String tableName) {
        CodeNamePair<String> myPair = new CodeNamePair<String>(code, tableName);
        if (this.pairs.contains(myPair)) {
            return false;
        } else {
            this.pairs.add(myPair);
        }
        return true;
    }

    public void addItem(String table, String key, String value) {
        if (this.tableItems.containsKey(table)) {
            this.tableItems.get(table).put(key, value);
        } else {
            HashMap<String, String> myHashMap = new HashMap<String, String>();
            myHashMap.put(key, value);
            this.tableItems.put(table, myHashMap);
        }

    }

    public HashMap<String, HashMap<String, String>> getTableItem() {
        return this.tableItems;
    }

    public boolean addType(String filed, String type) {
        CodeNamePair<String> newPair = new CodeNamePair<String>(filed, type);
        if (this.types.contains(newPair)) {
            return false;
        } else {
            this.types.add(newPair);
        }
        return true;
    }
    
    public String getPairSecond(String first){
        String second = null;
        for(int i=0; i < this.pairs.size(); i++){
            if(this.pairs.get(i).getFirst().equals(first)){
                second = this.pairs.get(i).getSecond().toString();
            }
        }
        return second;
    }
    
    /**
     * replace all items with $ symbol and add them to the table,
     * then delete all table items with $ symbol
     */
    public void refineTable(){
        HashMap<String, HashMap<String, String>> tmpTableItems = new HashMap<String, HashMap<String, String>>();
        Set<Entry<String, HashMap<String, String>>> tableItemSet = this.tableItems.entrySet();
        // replace all items with $ symbol 
        for (Map.Entry<String, HashMap<String, String>> entry : tableItemSet) {
            if(entry.getKey().contains("$")){
                String tableName = this.getPairSecond(entry.getKey());
                HashMap<String, String> tableContents = new HashMap<String, String>();
                tableContents = entry.getValue();
                Set<Entry<String, String>> contentsSet = tableContents.entrySet();
                for(Map.Entry<String, String> cEntry: contentsSet){
                    String field = null;
                    if((field = cEntry.getValue()).contains("$")){
                        field = this.getPairSecond(field);
                    }
                    this.addItem(tableName, cEntry.getKey(), field);
                }
            }
        }
        // remove all table items with $
        for (Map.Entry<String, HashMap<String, String>> entry : tableItemSet) {
            if(!entry.getKey().contains("$")){
                tmpTableItems.put(entry.getKey(), entry.getValue());
            }
        }
        this.tableItems.clear();
        this.tableItems = tmpTableItems;
    }

    public boolean toSQLFile(String filename) {

        return true;
    }

    public void outputData() {
        System.out.println("=================================================");

        Set<Entry<String, HashMap<String, String>>> tableItemSet = this.tableItems.entrySet();
        for (Map.Entry<String, HashMap<String, String>> entry : tableItemSet) {
            System.out.println(entry.getKey()+":");
            HashMap<String, String> tmpMap = entry.getValue();
            Set<Entry<String,String>> valueSet = tmpMap.entrySet();
            for(Map.Entry<String, String> tmpEntry: valueSet){
                System.out.printf("    %s", tmpEntry.getKey());
                System.out.println("    "+tmpEntry.getValue());
            }
        }
        System.out.println("=================================================");
        
        int listSize = this.types.size();
        for(int j=0; j<listSize; j++){
            System.out.println(this.types.get(j).getFirst()+":"+this.types.get(j).getSecond());
        }
    }
}

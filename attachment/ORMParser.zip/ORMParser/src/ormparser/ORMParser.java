/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ormparser;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 *
 * @author tang
 */
public class ORMParser {

    private Document dom;
    private String input;
    private String output;
    private MetaData sqlProvider;

    public ORMParser() {
    }

    public ORMParser(String input, String output) {
        this.input = input;
        this.output = output;
        this.sqlProvider = new MetaData();
    }

    public boolean toSQL() {
        readXMLFile();
        parseDocument();
        this.sqlProvider.toSQLFile(this.output);
        
        this.sqlProvider.refineTable();
        this.sqlProvider.outputData();
        //errorCheck(this.input);
        //wellFormed(this.input);

        //       MetaData mySQL = new MetaData();


        // test CodeNamePair
//        CodeNamePair<String> idpair = new CodeNamePair<String>("0","id");
//        CodeNamePair<String> valuepair = new CodeNamePair<String>("0","q");
//        CodeNamePair<String> namepair = new CodeNamePair<String>("0","name");
//        
//        mySQL.addItem(namepair, idpair, valuepair);
//
//        List<Map<CodeNamePair, CodeNamePair>> myList = mySQL.getTableItem();
//        for (int j = 0; j < myList.size(); j++) {
//            Set<Map.Entry<CodeNamePair, CodeNamePair>> mySet = mySQL.getTableItem().get(j).entrySet();
//            for (Map.Entry<CodeNamePair, CodeNamePair> entry : mySet) {
//                System.out.println(" Key: " + entry.getKey().getSecond());
//                System.out.println(" Value: " + entry.getValue().getSecond());
//            }
//        }

        //HashMap<String, String> first = (HashMap)mySQL.getTableItem().get(0);
        //String value = first.get("id");
        //System.out.println(value);
        return true;
    }

    public boolean toJPA() {
        return false;
    }

    /**
     * This method is used to check if the XML source file has errors
     *
     * @return true: if there are some errors, the stand output will show the
     * specific error false: no error
     */
    public boolean hasError() {
        try {
            File file = new File(this.input);
            if (file.exists()) {
                // Create a new factory
                DocumentBuilderFactory factory =
                        DocumentBuilderFactory.newInstance();
                // Use the factory to create builder document.
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document doc = builder.parse(this.input);
                System.out.println(this.input + " is well-formed!");
                return false;
            } else {
                System.out.print("File not found!");
            }
        } catch (SAXParseException e) {
            System.out.println("type" + ": " + e.getMessage() + "\n");
            System.out.println("Line " + e.getLineNumber() + " Column "
                    + e.getColumnNumber());

        } catch (SAXException e) {
            System.err.println(e);
            return true;
        } catch (ParserConfigurationException e) {
            System.err.println(e);
            return true;
        } catch (IOException e) {
            System.err.println(e);
            return true;
        }
        return false;
    }

    /**
     * Read the XML file
     */
    public void readXMLFile() {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            //Using factory get an instance of document builder
            DocumentBuilder db = dbf.newDocumentBuilder();
            //parse using builder to get DOM representation of the XML file
            dom = db.parse(this.input);
        } catch (ParserConfigurationException | SAXException | IOException pce) {
            pce.printStackTrace();
        }
    }

    /**
     * Parse the whole file
     */
    private void parseDocument() {
        try {
            //get the root element
            Element docEle = dom.getDocumentElement();
            //get a nodelist of  elements
            NodeList fieldnodes = docEle.getElementsByTagName("field");
            for (int i = 0; i < fieldnodes.getLength(); i++) {
                Node node = fieldnodes.item(i);
                // find different subnodes based on label value
                // find node if the "label" attribute is "primaryKey"
                if (node.hasAttributes()) {
                    Element element = (Element) node;
                    String labelValue = element.getAttribute("label");
                    switch (labelValue) {
                        case "primaryKey":
                            parsePK(element);
                            break;
                        case "fields":
                            parseFields(element);
                            break;
                        case "foreignKey":
                            parseFK(element);
                            break;
                        case "tAssociate":
                            parse_tAssociate(element);
                            break;
                        case "fAssociate":
                            parse_fAssociate(element);
                            break;
                        case "attrSet":
                            parseAttrSet(element);
                            break;
                        case "id":
                            parseId(element);
                            break;
                        case "parent":
                            parseParent(element);
                            break;
                        case "src":
                            parseSrc(element);
                            break;
                        case "dst":
                            parseDst(element);
                            break;
                        case "src_multiplicity":
                            parseSrcMultiplicity(element);
                            break;
                        case "dst_multiplicity":
                            parseDstMultiplicity(element);
                            break;
                        default:
                            break;
                    }

                }
            }

            // get sig nodes
            NodeList signodes = docEle.getElementsByTagName("sig");
            for (int i = 0; i < signodes.getLength(); i++) {
                Node node = signodes.item(i);
                // find different subnodes based on label value
                // find node if the "label" attribute is "primaryKey"
                if (node.hasAttributes()) {
                    Element element = (Element) node;
                    String labelValue = element.getAttribute("label");
                    String[] tmp = labelValue.split("/");
                    String type = tmp[tmp.length - 1];
                    if (type.equalsIgnoreCase("Real") || type.equalsIgnoreCase("Integer")) {
                        //System.out.println("Type: " + type);

                        NodeList atoms = element.getElementsByTagName("atom");
                        for (int j = 0; j < atoms.getLength(); j++) {
                            Node node1 = atoms.item(j);
                            Element tableCode = (Element) node1;
                            String code = tableCode.getAttribute("label");
                            String[] atomLabel = code.split("/");
                            String name = atomLabel[atomLabel.length - 1];
                            //System.out.println("    " + name);
                            this.sqlProvider.addType(name, type);
                        }
                    }
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * This method is used to parse the "tAssociate" tag of XML file
     * "tAssociate" tag includes the mapping of table code like "Table$0" to
     * table name like "Customer". The code and name will be stored in MetaData
     * variable "TableName"
     *
     * @param element: the input "tAssociate" tag
     * @return true if parse success
     */
    private void parse_tAssociate(Element element) {
        NodeList children = element.getElementsByTagName("tuple");

        for (int j = 0; j < children.getLength(); j++) {
            Node child = children.item(j);
            if (child.hasChildNodes()) { // for every <tuple> tag
                Element singleTuple = (Element) child;
                // every tuple pair includes two atom solo tags
                // the label attribute is what we need 
                String code = getSingleAtom(singleTuple, 0);    // Get the first part
                String name = getSingleAtom(singleTuple, 1);    // Get the second part
                //System.out.println(code + "+" + name + "+" + "Pair");
                this.sqlProvider.addPair(code, name);
            }
        }
    }

    /**
     * handle primary key
     *
     * @param element: the primary key tag
     * @return true: if parse successfully false: if parsing has failure
     */
    private void parsePK(Element element) {
        NodeList children = element.getElementsByTagName("tuple");
        //System.out.println("Tuple tags: " + children.getLength());
        for (int j = 0; j < children.getLength(); j++) {
            Node child = children.item(j);
            if (child.hasChildNodes()) {
                Element singleTuple = (Element) child;
                // Get the first atom
                String table = getSingleAtom(singleTuple, 0);
                // Get the second atom
                String key = getSingleAtom(singleTuple, 1);
                //System.out.println(table + "+" + "PrimaryKey" + "+" + key);
                this.sqlProvider.addItem(table, "primaryKey", key);
            }
        }
    }

    private void parseFK(Element element) {
        NodeList children = element.getElementsByTagName("tuple");

        for (int j = 0; j < children.getLength(); j++) {
            Node child = children.item(j);
            if (child.hasChildNodes()) { // for every <tuple> tag
                Element singleTuple = (Element) child;
                // every tuple pair includes two atom solo tags
                // the label attribute is what we need
                String table = getSingleAtom(singleTuple, 0);    // Get the first part
                String key = getSingleAtom(singleTuple, 1);    // Get the second part
                //System.out.println(table + "+" + "foreignKey" + "+" + key);
                this.sqlProvider.addItem(table, "foreignKey", key);
            }
        }
    }

    private void parseFields(Element element) {
        NodeList children = element.getElementsByTagName("tuple");

        for (int j = 0; j < children.getLength(); j++) {
            Node child = children.item(j);
            if (child.hasChildNodes()) { // for every <tuple> tag
                Element singleTuple = (Element) child;
                // every tuple pair includes two atom solo tags
                // the label attribute is what we need
                String table = getSingleAtom(singleTuple, 0);    // Get the first part
                String field = getSingleAtom(singleTuple, 1);    // Get the second part
                //System.out.println(table + "+" + "fields" + "+" + field);
                this.sqlProvider.addItem(table, "fields", field);
            }
        }
    }

    private void parse_fAssociate(Element element) {
        NodeList children = element.getElementsByTagName("tuple");

        for (int j = 0; j < children.getLength(); j++) {
            Node child = children.item(j);
            if (child.hasChildNodes()) { // for every <tuple> tag
                Element singleTuple = (Element) child;
                // every tuple pair includes two atom solo tags
                // the label attribute is what we need 
                String code = getSingleAtom(singleTuple, 0);    // Get the first part
                String name = getSingleAtom(singleTuple, 1);    // Get the second part
                //System.out.println(code + "+" + name + "+" + "Pair");
                this.sqlProvider.addPair(code, name);
            }
        }
    }

    private void parseId(Element element) {
        NodeList children = element.getElementsByTagName("tuple");

        for (int j = 0; j < children.getLength(); j++) {
            Node child = children.item(j);
            if (child.hasChildNodes()) { // for every <tuple> tag
                Element singleTuple = (Element) child;
                // every tuple pair includes two atom solo tags
                // the label attribute is what we need 
                String table = getSingleAtom(singleTuple, 0);    // Get the first part
                String Id = getSingleAtom(singleTuple, 1);    // Get the second part
                //System.out.println(table + "+" + "Id" + "+" + Id);
                this.sqlProvider.addItem(table, "Id", Id);
            }
        }
    }

    private void parseParent(Element element) {
        NodeList children = element.getElementsByTagName("tuple");

        for (int j = 0; j < children.getLength(); j++) {
            Node child = children.item(j);
            if (child.hasChildNodes()) { // for every <tuple> tag
                Element singleTuple = (Element) child;
                // every tuple pair includes two atom solo tags
                // the label attribute is what we need 
                String table = getSingleAtom(singleTuple, 0);    // Get the first part
                String parentTable = getSingleAtom(singleTuple, 1);    // Get the second part
                //System.out.println(table + "+" + "Parent" + "+" + parentTable);
                this.sqlProvider.addItem(table, "Parent", parentTable);
            }
        }
    }

    private void parseSrc(Element element) {
//        NodeList children = element.getElementsByTagName("tuple");
//
//        for (int j = 0; j < children.getLength(); j++) {
//            Node child = children.item(j);
//            if (child.hasChildNodes()) { // for every <tuple> tag
//                Element singleTuple = (Element) child;
//                // every tuple pair includes two atom solo tags
//                // the label attribute is what we need 
//                String table = getSingleAtom(singleTuple, 0);    // Get the first part
//                String parentTable = getSingleAtom(singleTuple, 1);    // Get the second part
//                System.out.println(table + "+" + parentTable);
//                this.sqlProvider.addItem(table, "Parent", parentTable);
//            }
//        }        
    }

    private void parseDst(Element element) {
//        NodeList children = element.getElementsByTagName("tuple");
//
//        for (int j = 0; j < children.getLength(); j++) {
//            Node child = children.item(j);
//            if (child.hasChildNodes()) { // for every <tuple> tag
//                Element singleTuple = (Element) child;
//                // every tuple pair includes two atom solo tags
//                // the label attribute is what we need 
//                String table = getSingleAtom(singleTuple, 0);    // Get the first part
//                String parentTable = getSingleAtom(singleTuple, 1);    // Get the second part
//                System.out.println(table + "+" + parentTable);
//                this.sqlProvider.addItem(table, "Parent", parentTable);
//            }
//        }    
    }

    private void parseSrcMultiplicity(Element element) {
//        NodeList children = element.getElementsByTagName("tuple");
//
//        for (int j = 0; j < children.getLength(); j++) {
//            Node child = children.item(j);
//            if (child.hasChildNodes()) { // for every <tuple> tag
//                Element singleTuple = (Element) child;
//                // every tuple pair includes two atom solo tags
//                // the label attribute is what we need 
//                String table = getSingleAtom(singleTuple, 0);    // Get the first part
//                String parentTable = getSingleAtom(singleTuple, 1);    // Get the second part
//                System.out.println(table + "+" + parentTable);
//                this.sqlProvider.addItem(table, "Parent", parentTable);
//            }
//        }    
    }

    private void parseDstMultiplicity(Element element) {
//        NodeList children = element.getElementsByTagName("tuple");
//
//        for (int j = 0; j < children.getLength(); j++) {
//            Node child = children.item(j);
//            if (child.hasChildNodes()) { // for every <tuple> tag
//                Element singleTuple = (Element) child;
//                // every tuple pair includes two atom solo tags
//                // the label attribute is what we need 
//                String table = getSingleAtom(singleTuple, 0);    // Get the first part
//                String parentTable = getSingleAtom(singleTuple, 1);    // Get the second part
//                System.out.println(table + "+" + parentTable);
//                this.sqlProvider.addItem(table, "Parent", parentTable);
//            }
//        }    
    }

    private void parseAttrSet(Element element) {
        NodeList children = element.getElementsByTagName("tuple");

        for (int j = 0; j < children.getLength(); j++) {
            Node child = children.item(j);
            if (child.hasChildNodes()) { // for every <tuple> tag
                Element singleTuple = (Element) child;
                // every tuple pair includes two atom solo tags
                // the label attribute is what we need 
                String table = getSingleAtom(singleTuple, 0);    // Get the first part
                String attr = getSingleAtom(singleTuple, 1);    // Get the second part
                //System.out.println(table + "+" + "attr" + "+" + attr);
                this.sqlProvider.addItem(table, "attr", attr);
            }
        }
    }

    public String getSingleAtom(Element singleTuple, int i) {
        NodeList atoms = singleTuple.getElementsByTagName("atom");
        Element tableCode = (Element) atoms.item(i);
        String code = tableCode.getAttribute("label");
        String[] tmp = code.split("/");
        code = tmp[tmp.length - 1];
        return code;
    }
}
